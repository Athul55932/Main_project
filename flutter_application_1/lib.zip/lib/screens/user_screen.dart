import 'package:flutter/material.dart';
import 'dart:convert';
import 'package:http/http.dart' as http;
import 'login_screen.dart';
import 'chatbot.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'certi_bot.dart';
import 'history.dart';
import 'complaint.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const SankalpApp());
}

class SankalpApp extends StatelessWidget {
  const SankalpApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Sankalp',
      theme: ThemeData(
        primarySwatch: Colors.indigo,
        scaffoldBackgroundColor: Colors.grey[50],
        appBarTheme: const AppBarTheme(
          backgroundColor: Colors.indigo,
          foregroundColor: Colors.white,
          elevation: 4,
          centerTitle: true,
        ),
        elevatedButtonTheme: ElevatedButtonThemeData(
          style: ElevatedButton.styleFrom(
            backgroundColor: Colors.indigo,
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(10),
            ),
            elevation: 3,
          ),
        ),
        textTheme: const TextTheme(
          bodyMedium: TextStyle(
              fontSize: 16, color: Colors.black87, fontFamily: 'CustomFont'),
          headlineSmall: TextStyle(
            fontSize: 20,
            fontWeight: FontWeight.bold,
            color: Colors.black,
            fontFamily: 'CustomFont',
          ),
          titleMedium: TextStyle(
              fontSize: 18, color: Colors.black87, fontFamily: 'CustomFont'),
        ),
        cardTheme: CardTheme(
          elevation: 2,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(10),
          ),
        ),
      ),
      home: const SankalpUI(),
      debugShowCheckedModeBanner: false,
    );
  }
}

class SankalpUI extends StatefulWidget {
  const SankalpUI({super.key});

  @override
  _SankalpUIState createState() => _SankalpUIState();
}

class _SankalpUIState extends State<SankalpUI>
    with SingleTickerProviderStateMixin {
  TabController? _tabController;
  String? _selectedService;
  String? userId;
  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _addressController = TextEditingController();
  Map<String, TextEditingController> controllers = {};

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
    _loadUserId();
  }

  Future<void> _loadUserId() async {
    final prefs = await SharedPreferences.getInstance();
    String? storedUserId = prefs.getString('user_id');
    if (storedUserId != null && storedUserId.isNotEmpty) {
      setState(() {
        userId = storedUserId;
      });
      print('Loaded User ID: $userId');
    } else {
      print('User ID not found in SharedPreferences.');
    }
  }

  @override
  void dispose() {
    _tabController?.dispose();
    _nameController.dispose();
    _addressController.dispose();
    for (var controller in controllers.values) {
      controller.dispose();
    }
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Row(
          children: [
            Image.asset('assets/logo.jpg', height: 30),
            const SizedBox(width: 10),
            const Text("Sankalp", style: TextStyle(fontFamily: 'CustomFont')),
          ],
        ),
        bottom: TabBar(
          controller: _tabController,
          indicatorColor: Colors.white,
          tabs: const [
            Tab(icon: Icon(Icons.chat), text: "Chatbot"),
            Tab(icon: Icon(Icons.document_scanner), text: "Services"),
          ],
        ),
      ),
      drawer: buildDrawer(context),
      body: TabBarView(
        controller: _tabController,
        children: [
          buildChatbotTab(context),
          buildServicesTab(),
        ],
      ),
    );
  }

  Widget buildDrawer(BuildContext context) {
    return Drawer(
      child: Container(
        color: Colors.grey[100],
        child: ListView(
          padding: EdgeInsets.zero,
          children: <Widget>[
            const DrawerHeader(
              decoration: BoxDecoration(
                color: Colors.indigo,
                boxShadow: [
                  BoxShadow(
                    color: Colors.black12,
                    blurRadius: 4,
                    offset: Offset(0, 2),
                  ),
                ],
              ),
              child: Column(
                children: [
                  CircleAvatar(
                    radius: 40,
                    backgroundImage: AssetImage('assets/logo.jpg'),
                  ),
                  SizedBox(height: 10),
                  Text(
                    'Sankalp App',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 24,
                      fontWeight: FontWeight.bold,
                      fontFamily: 'CustomFont',
                    ),
                  ),
                ],
              ),
            ),
            ListTile(
              leading: const Icon(Icons.chat, color: Colors.indigo),
              title: const Text(
                'Chat Bot',
                style: TextStyle(fontSize: 16, fontFamily: 'CustomFont'),
              ),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => const ChatbotScreen(),
                  ),
                );
              },
            ),
            ListTile(
              leading: const Icon(Icons.assignment, color: Colors.indigo),
              title: const Text(
                'Apply Certificate',
                style: TextStyle(fontSize: 16, fontFamily: 'CustomFont'),
              ),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => const ApplyCertificateScreen(),
                  ),
                );
              },
            ),
            ListTile(
              leading: const Icon(Icons.assignment, color: Colors.indigo),
              title: const Text(
                'Complaint Bot',
                style: TextStyle(fontSize: 16, fontFamily: 'CustomFont'),
              ),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => const ComplaintScreen(),
                  ),
                );
              },
            ),
            ListTile(
              leading: const Icon(Icons.document_scanner, color: Colors.indigo),
              title: const Text('Services',
                  style: TextStyle(fontSize: 16, fontFamily: 'CustomFont')),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => Scaffold(
                      appBar: AppBar(
                        title: const Text('Services',
                            style: TextStyle(fontFamily: 'CustomFont')),
                      ),
                      body: buildServicesTab(),
                    ),
                  ),
                );
              },
            ),
            ListTile(
              leading: const Icon(Icons.history, color: Colors.indigo),
              title: const Text('History',
                  style: TextStyle(fontSize: 16, fontFamily: 'CustomFont')),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => const HistoryScreen(),
                  ),
                );
              },
            ),
            const Divider(color: Colors.black54),
            ListTile(
              leading: const Icon(Icons.logout, color: Colors.indigo),
              title: const Text('Logout',
                  style: TextStyle(fontSize: 16, fontFamily: 'CustomFont')),
              onTap: () {
                Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(builder: (context) => const LoginScreen()),
                );
              },
            ),
          ],
        ),
      ),
    );
  }

  Widget buildChatbotTab(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: Card(
        elevation: 8,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
        ),
        child: Padding(
          padding: const EdgeInsets.all(20.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              ElevatedButton.icon(
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (context) => const ChatbotScreen()),
                  );
                },
                icon: const Icon(Icons.chat, color: Colors.white, size: 24),
                label: const Text(
                  "Open Chatbot",
                  style: TextStyle(
                      color: Colors.white,
                      fontSize: 18,
                      fontFamily: 'CustomFont'),
                ),
                style: ElevatedButton.styleFrom(
                  padding: const EdgeInsets.symmetric(vertical: 16),
                  textStyle: const TextStyle(fontWeight: FontWeight.bold),
                  backgroundColor: Colors.indigo,
                  foregroundColor: Colors.white,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                  elevation: 4,
                ),
              ),
              const SizedBox(height: 20),
              ElevatedButton.icon(
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (context) => const ApplyCertificateScreen()),
                  );
                },
                icon:
                    const Icon(Icons.assignment, color: Colors.white, size: 24),
                label: const Text(
                  "Apply Certificate",
                  style: TextStyle(
                      color: Colors.white,
                      fontSize: 18,
                      fontFamily: 'CustomFont'),
                ),
                style: ElevatedButton.styleFrom(
                  padding: const EdgeInsets.symmetric(vertical: 16),
                  textStyle: const TextStyle(fontWeight: FontWeight.bold),
                  backgroundColor: Colors.teal,
                  foregroundColor: Colors.white,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                  elevation: 4,
                ),
              ),
              const SizedBox(height: 20),
              ElevatedButton.icon(
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (context) => const ComplaintScreen()),
                  );
                },
                icon: const Icon(Icons.report_problem,
                    color: Colors.white, size: 24),
                label: const Text(
                  "Complaint Bot",
                  style: TextStyle(
                      color: Colors.white,
                      fontSize: 18,
                      fontFamily: 'CustomFont'),
                ),
                style: ElevatedButton.styleFrom(
                  padding: const EdgeInsets.symmetric(vertical: 16),
                  textStyle: const TextStyle(fontWeight: FontWeight.bold),
                  backgroundColor: Colors.deepOrange,
                  foregroundColor: Colors.white,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                  elevation: 4,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget buildServicesTab() {
    final Map<String, List<String>> certificateFields = {
      "Birth Certificate": [
        "name",
        "date_of_birth",
        "place_of_birth",
        "father_name",
        "mother_name"
      ],
      "Death Certificate": [
        "Name",
        "Date of Death",
        "Place of Death",
        "Cause of Death"
      ],
      "Land Certificate": [
        "Property Address",
        "Owner Name",
        "Survey Number",
        "Area (in sq. ft.)",
        "Market Value"
      ],
      "Income Certificate": [
        "Name",
        "Annual Income",
        "Source of Income",
        "Address"
      ],
    };

    return StatefulBuilder(
      builder: (BuildContext context, StateSetter setState) {
        return Padding(
          padding: const EdgeInsets.all(16.0),
          child: SingleChildScrollView(
            child: Column(
              children: [
                Card(
                  elevation: 2,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Padding(
                    padding: const EdgeInsets.all(16.0),
                    child: DropdownButtonFormField<String>(
                      decoration: InputDecoration(
                        labelText: 'Select Certificate',
                        enabledBorder: OutlineInputBorder(
                          borderSide: const BorderSide(color: Colors.black38),
                          borderRadius: BorderRadius.circular(10),
                        ),
                        focusedBorder: OutlineInputBorder(
                          borderSide: const BorderSide(color: Colors.indigo),
                          borderRadius: BorderRadius.circular(10),
                        ),
                      ),
                      items: certificateFields.keys.map((certificate) {
                        return DropdownMenuItem<String>(
                          value: certificate,
                          child: Text(certificate,
                              style: const TextStyle(fontFamily: 'CustomFont')),
                        );
                      }).toList(),
                      onChanged: (value) {
                        setState(() {
                          _selectedService = value;
                          controllers.clear();
                        });
                      },
                      hint: const Text("Select Certificate",
                          style: TextStyle(fontFamily: 'CustomFont')),
                    ),
                  ),
                ),
                if (_selectedService != null)
                  Card(
                    elevation: 2,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Padding(
                      padding: const EdgeInsets.all(16.0),
                      child: Column(
                        children: [
                          for (var field
                              in certificateFields[_selectedService]!)
                            Padding(
                              padding:
                                  const EdgeInsets.symmetric(vertical: 8.0),
                              child: TextField(
                                controller: controllers[field] ??=
                                    TextEditingController(),
                                decoration: InputDecoration(
                                  labelText: field,
                                  border: const OutlineInputBorder(),
                                  enabledBorder: OutlineInputBorder(
                                    borderSide:
                                        const BorderSide(color: Colors.black38),
                                    borderRadius: BorderRadius.circular(10),
                                  ),
                                  focusedBorder: OutlineInputBorder(
                                    borderSide:
                                        const BorderSide(color: Colors.indigo),
                                    borderRadius: BorderRadius.circular(10),
                                  ),
                                ),
                              ),
                            ),
                          ElevatedButton(
                            onPressed: () async {
                              if (_selectedService != null) {
                                Map<String, String> formData = {};
                                for (var field
                                    in certificateFields[_selectedService]!) {
                                  formData[field] =
                                      controllers[field]?.text ?? '';
                                }
                                await submitForm(formData, _selectedService!);
                              }
                            },
                            child: const Text(
                              'Submit',
                              style: TextStyle(
                                  color: Colors.white,
                                  fontFamily: 'CustomFont'),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
              ],
            ),
          ),
        );
      },
    );
  }

  Future<void> submitForm(
      Map<String, String> formData, String certificateType) async {
    if (userId == null || userId!.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
            content: Text('User ID not found. Please log in again.',
                style: TextStyle(fontFamily: 'CustomFont'))),
      );
      return;
    }

    final url = Uri.parse('http://127.0.0.1:5500/certificate/save_certificate');

    try {
      Map<String, String> normalizedFormData = {};
      formData.forEach((key, value) {
        String normalizedKey = key
            .toLowerCase()
            .replaceAll(' ', '_')
            .replaceAll(RegExp(r"[().']"), '');

        normalizedFormData[normalizedKey] = value;
      });

      final response = await http.post(
        url,
        headers: {'Content-Type': 'application/json'},
        body: json.encode({
          'certificate_type': certificateType,
          'data': normalizedFormData,
          'user_id': userId,
        }),
      );

      if (response.statusCode == 200) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
              content: Text('Form submitted successfully!',
                  style: TextStyle(fontFamily: 'CustomFont'))),
        );

        for (var controller in controllers.values) {
          controller.clear();
        }

        setState(() {
          _selectedService = null;
        });
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
              content: Text('Error submitting form: ${response.body}',
                  style: const TextStyle(fontFamily: 'CustomFont'))),
        );
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
            content: Text('Network error. Please try again.',
                style: TextStyle(fontFamily: 'CustomFont'))),
      );
    }
  }
}

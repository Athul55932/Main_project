import 'package:flutter/material.dart';
import 'dart:convert';
import 'package:http/http.dart' as http;

class CertificateListScreen extends StatefulWidget {
  const CertificateListScreen({super.key});

  @override
  _CertificateListScreenState createState() => _CertificateListScreenState();
}

class _CertificateListScreenState extends State<CertificateListScreen> {
  List<Map<String, dynamic>> certificates = [];
  bool isLoading = true;
  String certificateType = 'Income Certificate';
  Map<String, String> certificateStatuses = {};

  final ScrollController _scrollController = ScrollController();

  final List<String> certificateTypes = [
    'Birth Certificate',
    'Death Certificate',
    'Income Certificate',
    'Land Certificate',
  ];

  final Map<String, List<String>> certificateAttributes = {
    "Birth Certificate": [
      "name",
      "date_of_birth",
      "place_of_birth",
      "father_name",
      "mother_name"
    ],
    'Death Certificate': [
      'name',
      'date_of_death',
      'place_of_death',
      'cause_of_death',
    ],
    'Income Certificate': [
      'name',
      'annual_income',
      'source_of_income',
      'address'
    ],
    'Land Certificate': [
      'owner_name',
      'property_address',
      'market_value',
      'area_sqft',
      'survey_number'
    ],
  };

  @override
  void initState() {
    super.initState();
    fetchCertificates();
  }

  Future<void> fetchCertificates() async {
    try {
      setState(() {
        isLoading = true;
      });

      final response = await http.get(
        Uri.parse(
          'http://127.0.0.1:5500/fetch/fetch_application_data?certificate_type=$certificateType',
        ),
      );

      if (response.statusCode == 200) {
        final responseBody = json.decode(response.body);
        print('Raw API Response: $responseBody');

        List<Map<String, dynamic>> parsedCertificates = [];
        if (responseBody is Map && responseBody.containsKey('data')) {
          var data = responseBody['data'];
          if (data is List) {
            parsedCertificates = List<Map<String, dynamic>>.from(data);
          }
        }

        Map<String, String> newStatuses = {};
        for (var cert in parsedCertificates) {
          String id = cert['application_id']?.toString() ?? '';
          print('Found ID: $id for certificate: $cert');
          newStatuses[id] = cert['status']?.toString() ?? 'Pending';
        }

        setState(() {
          certificates = parsedCertificates;
          certificateStatuses = newStatuses;
          isLoading = false;
        });
      } else {
        print('Error Response: ${response.statusCode} - ${response.body}');
        throw Exception(
            'Failed to fetch certificates. Status: ${response.statusCode}');
      }
    } catch (e) {
      print('Error fetching certificates: $e');
      setState(() {
        certificates = [];
        isLoading = false;
      });
    }
  }

  Future<void> updateCertificateStatus(
      String certificateId, String action) async {
    if (certificateId.isEmpty) {
      print('Error: Certificate ID is empty.');
      return;
    }

    try {
      print(
          'Sending update request for certificate $certificateId with action: $action');

      final requestBody = {
        'certificateId': certificateId,
        'action': action,
      };

      print('Request body: $requestBody');

      final response = await http.post(
        Uri.parse('http://127.0.0.1:5500/fetch/update_certificate_status'),
        headers: {'Content-Type': 'application/json'},
        body: json.encode(requestBody),
      );

      print('Response status code: ${response.statusCode}');
      print('Response body: ${response.body}');

      if (response.statusCode == 200) {
        setState(() {
          certificateStatuses[certificateId] =
              action == 'approve' ? 'Approved' : 'Rejected';
        });
        print('Successfully updated certificate status');
      } else {
        print('Failed to update certificate status: ${response.body}');
      }
    } catch (e) {
      print('Error updating certificate status: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        title: Text('$certificateType List'),
        actions: [
          DropdownButtonHideUnderline(
            child: DropdownButton<String>(
              value: certificateType,
              icon: const Icon(Icons.arrow_downward, color: Colors.white),
              dropdownColor: Colors.white,
              onChanged: (String? newValue) {
                if (newValue != null) {
                  setState(() {
                    certificateType = newValue;
                  });
                  fetchCertificates();
                }
              },
              items: certificateTypes.map((String value) {
                return DropdownMenuItem<String>(
                  value: value,
                  child: Text(
                    value.replaceAll('_', ' '),
                    style: const TextStyle(color: Colors.black),
                  ),
                );
              }).toList(),
            ),
          ),
        ],
      ),
      body: isLoading
          ? const Center(child: CircularProgressIndicator())
          : certificates.isEmpty
              ? const Center(child: Text('No certificates found'))
              : Scrollbar(
                  controller: _scrollController, // Fix for scroll issue
                  child: SingleChildScrollView(
                    controller: _scrollController,
                    scrollDirection: Axis.horizontal,
                    child: SingleChildScrollView(
                      scrollDirection: Axis.vertical,
                      child: DataTable(
                        headingRowColor: WidgetStateColor.resolveWith(
                          (states) => Colors.indigoAccent,
                        ),
                        columns: [
                          ...certificateAttributes[certificateType]!
                              .map((attribute) => DataColumn(
                                    label: Text(
                                      attribute.replaceAll('_', ' '),
                                      style: const TextStyle(
                                        fontWeight: FontWeight.bold,
                                        color: Colors.white,
                                      ),
                                    ),
                                  )),
                          const DataColumn(
                            label: Text(
                              'Action',
                              style: TextStyle(
                                fontWeight: FontWeight.bold,
                                color: Colors.white,
                              ),
                            ),
                          ),
                        ],
                        rows: certificates.map((certificate) {
                          String certId =
                              certificate['application_id']?.toString() ?? '';
                          print('Using ID: $certId');

                          Map<String, dynamic> applicationData =
                              certificate['application_data'] ?? {};

                          return DataRow(
                            cells: [
                              ...certificateAttributes[certificateType]!
                                  .map((attr) => DataCell(
                                        Text(
                                          applicationData[attr]?.toString() ??
                                              'N/A',
                                          style: const TextStyle(
                                              color: Colors.black87),
                                        ),
                                      )),
                              DataCell(
                                Container(
                                  constraints:
                                      const BoxConstraints(maxWidth: 200),
                                  child: Row(
                                    mainAxisSize: MainAxisSize.min,
                                    children: [
                                      ElevatedButton(
                                        onPressed:
                                            certificateStatuses[certId] ==
                                                    'Approved'
                                                ? null
                                                : () => updateCertificateStatus(
                                                    certId, 'approve'),
                                        style: ElevatedButton.styleFrom(
                                          backgroundColor: Colors.green,
                                        ),
                                        child: const Text('Approve'),
                                      ),
                                      const SizedBox(width: 8),
                                      ElevatedButton(
                                        onPressed:
                                            certificateStatuses[certId] ==
                                                    'Rejected'
                                                ? null
                                                : () => updateCertificateStatus(
                                                    certId, 'reject'),
                                        style: ElevatedButton.styleFrom(
                                          backgroundColor: Colors.red,
                                        ),
                                        child: const Text('Reject'),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ],
                          );
                        }).toList(),
                      ),
                    ),
                  ),
                ),
    );
  }
}

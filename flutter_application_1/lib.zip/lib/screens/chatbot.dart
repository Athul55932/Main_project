import 'package:flutter/material.dart';
import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:uuid/uuid.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:speech_to_text/speech_to_text.dart' as stt;
import 'package:permission_handler/permission_handler.dart';

class ChatbotScreen extends StatefulWidget {
  const ChatbotScreen({super.key});

  @override
  _ChatbotScreenState createState() => _ChatbotScreenState();
}

class _ChatbotScreenState extends State<ChatbotScreen> {
  final TextEditingController _queryController = TextEditingController();
  List<dynamic> _chatHistory = [];
  String? _sessionId;
  final ScrollController _scrollController = ScrollController();

  // Speech-to-Text variables
  final stt.SpeechToText _speech = stt.SpeechToText();
  bool _isListening = false;
  String _selectedLanguage = 'en_US'; // Default language is English

  @override
  void initState() {
    super.initState();
    _initializeSession();
    _initializeSpeechRecognition();
  }

  Future<void> _initializeSession() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    String? sessionId = prefs.getString('session_id');

    if (sessionId == null) {
      sessionId = const Uuid().v4();
      await prefs.setString('session_id', sessionId);
    }

    setState(() {
      _sessionId = sessionId;
    });

    await fetchChatHistory();
  }

  Future<void> _initializeSpeechRecognition() async {
    bool available = await _speech.initialize(
      onStatus: (status) => print('Speech status: $status'),
      onError: (error) => print('Speech error: $error'),
    );

    if (!available) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Speech recognition not available')),
      );
    }
  }

  Future<void> _startListening(String languageCode) async {
    var status = await Permission.microphone.request();
    if (status != PermissionStatus.granted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Microphone permission required')),
      );
      return;
    }

    if (!_isListening) {
      setState(() => _isListening = true);

      try {
        await _speech.listen(
          onResult: (result) {
            setState(() {
              _queryController.text = result.recognizedWords;
            });
          },
          localeId: languageCode,
          listenMode: stt.ListenMode.confirmation,
          cancelOnError: true,
        );
      } catch (e) {
        print('Speech recognition error: $e');
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error: $e')),
        );
        setState(() => _isListening = false);
      }
    } else {
      setState(() => _isListening = false);
      _speech.stop();
    }
  }

  Future<void> sendQuery() async {
    if (_queryController.text.trim().isEmpty) return;

    final url = Uri.parse('http://127.0.0.1:5500/sample/ask_pdf');
    try {
      final response = await http.post(
        url,
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'query': _queryController.text,
          'session_id': _sessionId,
        }),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        setState(() {
          _chatHistory.addAll([
            {'role': 'human', 'content': _queryController.text},
            {'role': 'ai', 'content': data['answer']},
          ]);
          _queryController.clear();
        });
        _scrollToBottom();
      }
    } catch (e) {
      setState(() {
        _chatHistory.add({
          'role': 'error',
          'content': 'Failed to fetch response. Please try again.',
        });
      });
    }
  }

  Future<void> fetchChatHistory() async {
    if (_sessionId == null) return;

    final url = Uri.parse('http://127.0.0.1:5500/get_chat_history');
    try {
      final response = await http.post(
        url,
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'session_id': _sessionId}),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        setState(() {
          _chatHistory = data['history'];
        });
        _scrollToBottom();
      }
    } catch (e) {
      print('Error fetching chat history: $e');
    }
  }

  void _scrollToBottom() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scrollController.hasClients) {
        _scrollController.animateTo(
          _scrollController.position.maxScrollExtent,
          duration: const Duration(milliseconds: 300),
          curve: Curves.easeOut,
        );
      }
    });
  }

  Widget _buildChatBubble(String content, bool isHuman) {
    return Align(
      alignment: isHuman ? Alignment.centerRight : Alignment.centerLeft,
      child: Container(
        margin: const EdgeInsets.symmetric(vertical: 5, horizontal: 10),
        padding: const EdgeInsets.all(10),
        constraints: BoxConstraints(
          maxWidth: MediaQuery.of(context).size.width * 0.7,
        ),
        decoration: BoxDecoration(
          color: isHuman ? Colors.blue : Colors.green,
          borderRadius: BorderRadius.circular(10),
        ),
        child: Text(
          content,
          style: const TextStyle(color: Colors.white, fontSize: 16),
        ),
      ),
    );
  }

  @override
  void dispose() {
    _queryController.dispose();
    _speech.stop();
    _scrollController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[200],
      appBar: AppBar(
        backgroundColor: Colors.teal,
        title: const Text(
          'Sankalp Chatbot',
          style: TextStyle(color: Colors.white),
        ),
      ),
      body: Column(
        children: [
          Expanded(
            child: ListView.builder(
              controller: _scrollController,
              itemCount: _chatHistory.length,
              itemBuilder: (context, index) {
                final message = _chatHistory[index];
                final isHuman = message['role'] == 'human';
                return _buildChatBubble(message['content'], isHuman);
              },
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Row(
              children: [
                DropdownButton<String>(
                  value: _selectedLanguage,
                  onChanged: (String? newValue) {
                    setState(() {
                      _selectedLanguage = newValue!;
                    });
                  },
                  items: const [
                    DropdownMenuItem(
                      value: 'en_US',
                      child: Text('English'),
                    ),
                    DropdownMenuItem(
                      value: 'ml_IN',
                      child: Text('Malayalam'),
                    ),
                  ],
                ),
                Container(
                  margin: const EdgeInsets.only(right: 8.0),
                  decoration: BoxDecoration(
                    color: _isListening ? Colors.red : Colors.blue,
                    shape: BoxShape.circle,
                  ),
                  child: IconButton(
                    icon: Icon(
                      _isListening ? Icons.mic : Icons.mic_none,
                      color: Colors.white,
                    ),
                    onPressed: () => _startListening(_selectedLanguage),
                  ),
                ),
                Expanded(
                  child: TextField(
                    controller: _queryController,
                    decoration: InputDecoration(
                      hintText: 'Ask a question...',
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10),
                      ),
                      suffixIcon: IconButton(
                        icon: const Icon(Icons.send),
                        onPressed: sendQuery,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
